eval("<img src=x onerror=alert(1)>");
