Exemplo simples sem regras disparadas. Isso nao garante seguranca.
