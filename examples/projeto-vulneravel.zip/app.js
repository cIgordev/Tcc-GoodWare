// Fixture de texto para analise; nao executar.
eval(atob(payload));
