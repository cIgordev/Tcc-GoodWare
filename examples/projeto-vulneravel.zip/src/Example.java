// Fixture de texto para analise; nao executar.
class Example {
 void run(String input) throws Exception {
  Runtime.getRuntime().exec(input);
 }
}
